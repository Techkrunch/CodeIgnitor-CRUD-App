-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2019 at 05:51 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abc`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(100) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `submit_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `fullname`, `email`, `subject`, `msg`, `submit_date`) VALUES
(1, 'Ian jan', 'ian@gmail.com', 'aaaaaaaaaaaa', 'asdfhgf', '2019-11-16 08:31:14'),
(2, 'Ian jan', 'ian@gmail.com', 'aaaaaaaaaaaa', 'asdfhgf', '2019-11-16 08:32:08'),
(3, 'asdasda', 'admin@gmail.com', 'asdasd', '<script src=\"https://cdn.jsdelivr.net/npm/promise-polyfill\"></script>', '2019-11-16 19:00:31'),
(4, 'asdasda', 'admin@gmail.com', 'aaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2019-11-16 19:01:32'),
(5, 'Ian jan', 'admin@gmail.com', 'aaaaaaaaaaaa', '<script>\r\n              swal({\r\n                title: \"Success\",\r\n                text: \"<?php echo $this->session->flashdata(\'msg\'); ?>\",\r\n                timer: 1500,\r\n                showConfirmButton: false,\r\n                type: \'success\'\r\n              });\r\n            </script>', '2019-11-16 19:02:30'),
(6, 'sweetalert2.min.css', 'sweetalert2.min.css', 'sweetalert2.min.css', 'sweetalert2.min.css', '2019-11-16 19:05:32'),
(7, 'sweetalert2.min.css', 'sweetalert2.min.css', 'sweetalert2.min.css', 'sweetalert2.min.css', '2019-11-16 19:13:00'),
(8, 'asdasda', 'ian@gmail.com', 'asdasd', '<?php if ($this->session->flashdata(\'flash_message\')): ?>\r\n                            <script>\r\n                                swal({\r\n                                    title: \"Done\",\r\n                                    text: \"<?php echo $this->session->flashdata(\'flash_message\'); ?>\",\r\n                                    timer: 1500,\r\n                                    showConfirmButton: false,\r\n                                    type: \'success\'\r\n                                });\r\n                            </script>\r\n                    <?php endif; ?>', '2019-11-16 19:13:20'),
(9, 'asdasda', 'ian@gmail.com', 'asdasd', '<?php if ($this->session->flashdata(\'flash_message\')): ?>\r\n                            <script>\r\n                                swal({\r\n                                    title: \"Done\",\r\n                                    text: \"<?php echo $this->session->flashdata(\'flash_message\'); ?>\",\r\n                                    timer: 1500,\r\n                                    showConfirmButton: false,\r\n                                    type: \'success\'\r\n                                });\r\n                            </script>\r\n                    <?php endif; ?>', '2019-11-16 19:14:00'),
(10, 'asdasda', 'ian@gmail.com', 'asdasd', '<?php if ($this->session->flashdata(\'flash_message\')): ?>\r\n                            <script>\r\n                                swal({\r\n                                    title: \"Done\",\r\n                                    text: \"<?php echo $this->session->flashdata(\'flash_message\'); ?>\",\r\n                                    timer: 1500,\r\n                                    showConfirmButton: false,\r\n                                    type: \'success\'\r\n                                });\r\n                            </script>\r\n                    <?php endif; ?>', '2019-11-16 19:14:46'),
(11, 'asdasda', 'ian@gmail.com', 'asdasd', '<?php if ($this->session->flashdata(\'flash_message\')): ?>\r\n                            <script>\r\n                                swal({\r\n                                    title: \"Done\",\r\n                                    text: \"<?php echo $this->session->flashdata(\'flash_message\'); ?>\",\r\n                                    timer: 1500,\r\n                                    showConfirmButton: false,\r\n                                    type: \'success\'\r\n                                });\r\n                            </script>\r\n                    <?php endif; ?>', '2019-11-16 19:15:10'),
(12, 'asdasda', 'ian@gmail.com', 'asdasd', '<?php if ($this->session->flashdata(\'flash_message\')): ?>\r\n                            <script>\r\n                                swal({\r\n                                    title: \"Done\",\r\n                                    text: \"<?php echo $this->session->flashdata(\'flash_message\'); ?>\",\r\n                                    timer: 1500,\r\n                                    showConfirmButton: false,\r\n                                    type: \'success\'\r\n                                });\r\n                            </script>\r\n                    <?php endif; ?>', '2019-11-16 19:15:30'),
(13, 'asdasda', 'ian@gmail.com', 'asdasd', '<?php if ($this->session->flashdata(\'flash_message\')): ?>\r\n                            <script>\r\n                                swal({\r\n                                    title: \"Done\",\r\n                                    text: \"<?php echo $this->session->flashdata(\'flash_message\'); ?>\",\r\n                                    timer: 1500,\r\n                                    showConfirmButton: false,\r\n                                    type: \'success\'\r\n                                });\r\n                            </script>\r\n                    <?php endif; ?>', '2019-11-16 19:34:49'),
(14, 'Ian jan', 'admin@gmail.com', 'aaaaaaaaaaaa', 'asddas', '2019-11-16 19:36:02'),
(15, 'Ian jan', 'admin@gmail.com', 'aaaaaaaaaaaa', 'asddas', '2019-11-16 19:37:05'),
(16, 'Ian jan', 'admin@gmail.com', 'aaaaaaaaaaaa', 'asddas', '2019-11-16 19:39:17'),
(17, 'Ian jan', 'admin@gmail.com', 'aaaaaaaaaaaa', 'asddas', '2019-11-16 19:40:42');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `educational_background` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `registration_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `fname`, `lname`, `city`, `dob`, `phone`, `gender`, `educational_background`, `email`, `password`, `registration_date`) VALUES
(1, 'rahab', 'ian', 'thika', '2009-11-22', '0715012649', 'male', 'Highschool', 'a@gmail.com', '$2y$10$KvfkkGPUyOFSwOVH1/14Ie1K6oLxQ8ZE7zPcLUSGUSa4ms//NZWfe', '2019-11-15 16:39:41'),
(5, 'bloodtype', 'bloodtype', 'thika', '2019-01-04', '0715012649', 'male', 'Diploma', 'kipngetich311@gmail.com', '$2y$10$4i43auFH9GKRKiu47KvHNOR6KWgWA00HVIHSaHha2yikMXiZR5/1y', '2019-11-20 09:23:56'),
(6, 'bloodtype', 'bloodtype', 'thika', '2019-01-04', '0715012649', 'male', 'Diploma', 'z@gmail.com', '$2y$10$Uuesz6c9x6TM8Pf6XsYic.CpYCHj5ATykXYdBmW7ax/eS/YPZoMa2', '2019-11-20 09:25:56');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `id` int(100) NOT NULL,
  `job_category` varchar(100) NOT NULL,
  `job_name` varchar(100) NOT NULL,
  `job_salary` varchar(15) NOT NULL,
  `job_duration` varchar(100) NOT NULL,
  `job_location` varchar(100) NOT NULL,
  `job_status` varchar(100) NOT NULL,
  `job_description` text NOT NULL,
  `upload_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`id`, `job_category`, `job_name`, `job_salary`, `job_duration`, `job_location`, `job_status`, `job_description`, `upload_date`) VALUES
(1, 'Engineering', 'Road Survey', '1500', '4', 'Nairobi, Kenya', 'active', 'Company Description: InterIntel Technologies is an IT company based in Nairobi with an array of services ranging from software development, payment aggregations on mobile, web and applications, loyalty programs, premium rate service provision (IVR, SMS, USSD) among  others. Our forte is…', '2019-11-15 03:10:13'),
(2, 'Writing', 'Alexandre', '250', '1', 'Thika,Kiambu', 'active', 'BoP Innovation Center is looking for a Digital Innovation Specialist to support the scouting, piloting and scaling of digital solutions for agribusinesses in our 2SCALE program.  2SCALE is one of the largest incubators and accelerators for inclusive agribusiness partnerships in Africa.…', '2019-11-15 00:00:00'),
(3, 'IT', 'Software Development', '4500', '14', 'Machakos,Kenya', 'active', 'What is BuuPass? BuuPass works with transport operators to provide digital solutions that seamlessly facilitate convenient and reliable movement for commuters.    Currently, we have partnered with Easy Coach, Modern Coast, Greenline and other  bus companies to facilitate…', '2019-11-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `applicant_id` int(100) NOT NULL,
  `job_id` int(100) NOT NULL,
  `application_status` varchar(100) NOT NULL,
  `application_date` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job_applications`
--

INSERT INTO `job_applications` (`applicant_id`, `job_id`, `application_status`, `application_date`, `id`) VALUES
(5, 1, 'pending', '2019-11-20 13:52:08', 1),
(5, 1, 'pending', '2019-11-20 13:52:32', 2),
(5, 1, 'pending', '2019-11-20 13:57:17', 3),
(5, 1, 'pending', '2019-11-20 13:57:20', 4);

-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--

CREATE TABLE `qualifications` (
  `id` int(100) NOT NULL,
  `category` int(100) NOT NULL,
  `qualifications` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `applicant_id` (`applicant_id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `qualifications`
--
ALTER TABLE `qualifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`category`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `qualifications`
--
ALTER TABLE `qualifications`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD CONSTRAINT `job_applications_ibfk_1` FOREIGN KEY (`applicant_id`) REFERENCES `employees` (`id`),
  ADD CONSTRAINT `job_applications_ibfk_2` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

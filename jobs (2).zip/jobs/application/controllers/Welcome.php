<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{
	// public $CI = NULL;
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->model('db_model');
		// load Session Library
		$this->load->library('session');
	}
	public function login()
	{
		$this->load->view('login');
	}
	public function account()
	{
		$this->load->view('account');
	}
	public function index()
	{
		$query = $this->db_model->getAll('job', '10');
		$data['a'] = null;
		if ($query) {
			$data['a'] =  $query;
		}
		$this->load->view('home', $data);
	}



	public function contact()
	{
		$this->load->view('contact');
	}
	public function register()
	{
		$this->load->view('register');
	}
	public function Home()
	{
		$this->load->view('home');
	}
	// login functions
	public function submitPassword()
	{
		$password = $this->input->post('password');
		$data = array(
			'email' => $this->input->post('email')
		);
		$message = array(
			'error' => 'User Login Failed. Use valid Credentials.'
		);
		$access = $this->db_model->login_access('employees', $data, $password);
		//print_r ($access); die;
		$user_data = $access[0];
		if (count($user_data) > 0) {
			$data['user_data'] = $user_data;
			$userData = array(
				'fname'          => $user_data->fname,
				'lname'          => $user_data->lname,
				'id'         => $user_data->id,
				'registration_date'     => $user_data->registration_date,
				'email'         => $user_data->email,
				// 'group'            => $user_data->group_id_fk,
				'logged_in' => TRUE
			);
			$this->session->set_userdata($userData);
			redirect('welcome/');
		} else {
			$this->session->set_flashdata('msg_login', $message['error']);
			redirect('welcome/login');
		}
	}
	public function register_user()
	{
		$data = array(
			'email' => $this->input->post('email')
		);
		$message = array(
			'error' => 'A User already exists with that Email',
			'success' => 'User Created Successfully. '
		);

		$user_exists = $this->db_model->getAllSpecific('employees', $data);
		if (!$user_exists) {
			$password = $this->input->post('password');
			$hashed_password = password_hash($password, PASSWORD_BCRYPT);
			//echo $hashed_password; die;
			$data = array(
				'fname' => $this->input->post('fname'),
				'lname' => $this->input->post('lname'),
				'city' => $this->input->post('city'),
				'dob' => $this->input->post('dob'),
				'phone' => $this->input->post('phone'),
				'gender' => $this->input->post('gender'),
				'educational_background' => $this->input->post('educational_background'),
				'email' => $this->input->post('email'),
				'password' => $hashed_password,
				// 'group_id_fk'=>$this->input->post('group_id'),
				'registration_date' => date("Y-m-d H:i:s")
			);
			$this->db_model->dbInsert('employees', $data);
			//$this->sendSMS($data['contact_number'], urlencode($otp_message));
			/**$otp_data = array(
            'contact_number'=>$data['contact_number'],
                'otp'=>$otp
            );*/
			//$this->session->set_userdata($otp_data);
			$this->session->set_flashdata('msg_register', $message['success']);

			redirect('welcome/register');
		} else {
			$this->session->set_flashdata('message', $message['error']);
			redirect('welcome/functionname');
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('welcome/login');
	}
	public function filterSearch()
	{
		$job_category = $this->input->post('filter');
		$data = array(
			'job_category' => $job_category
		);
		$query = $this->db_model->getAllSpecific('job', $data);
		$data['a'] = null;
		if ($query) {
			$data['a'] =  $query;
		}
		$this->load->view('home', $data);
	}



	public function job_get($id)
	{
		// public function display($id)
		// {
		// 	$this->db->where('id', $id);
		// 	$query = $this->db->get('messages');
		// 	$this->TPL['message'] = $query->result_array();
		// 	$this->template->show('Message', $this->TPL);
		// }

		$dataa = array(
			'id' => $id
		);
		$query = $this->db_model->getAll('job', $dataa);

		$data_['job_array'] = null;
		if ($query) {
			$data_['job_array'] =  $query;
		}
		$this->load->view('job', $data_);
	}
	public function apply($job_id)
	{
		$applicant = $this->session->userData('id');
		// print_r ($applicant);die();
		$data1 = array(
			'applicant_id' => $applicant,
			'job_id' => $job_id

		);
		$data = array(
			'job_id' => $job_id,
			'applicant_id' => $applicant,
			'application_status' => 'pending',
			'application_date'  =>  date("Y-m-d H:i:s")
		);
		$message = array(
			'success' => 'Job Application Successful. Wait for Confirmation from Owner. ',
			'error' => 'You have already applied for that this Job. '
		);

		$user_exists = $this->db_model->getAllSpecific('job_applications', $data1);
		if (!$user_exists) {
			$this->db_model->dbInsert('job_applications', $data);
			$this->session->set_flashdata('msg_update', $message['success']);
			redirect('welcome/job_get/' . $job_id);
		} else {
			$this->session->set_flashdata('msg_error', $message['error']);
			redirect('welcome/job_get/' . $job_id);
		}
	}
	public function contact_Mgs()
	{
		$message = array(
			'success' => 'Successfully Submitted. '
		);

		$data = array(
			'fullname' => $this->input->post('fullname'),
			'email' => $this->input->post('email'),
			'subject' => $this->input->post('subject'),
			'msg' => $this->input->post('msg'),
			'submit_date' => date("Y-m-d H:i:s")
		);
		$this->db_model->dbInsert('contact', $data);
		//$this->sendSMS($data['contact_number'], urlencode($otp_message));
		/**$otp_data = array(
            'contact_number'=>$data['contact_number'],
                'otp'=>$otp
            );*/
		//$this->session->set_userdata($otp_data);
		$this->session->set_flashdata('msg', $message['success']);
		redirect('welcome/contact');
	}
}

<?php

?>

<!-- start footer Area -->
<footer>

	<section class="footer-Content">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6 col-xs-12 wow fadeIn animated" data-wow-delay="0.2s" style="visibility: visible;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">
					<div class="widget">
						<h3 class="block-title">About us</h3>
						<div class="textwidget">
							<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia fugiat accusantium cum perferendis impedit, dolorum obcaecati nulla assumenda! Ea sint nisi est illo sapiente recusandae necessitatibus adipisci, tempore
								quasi fuga.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-xs-12 wow fadeIn animated" data-wow-delay="0.4s" style="visibility: visible;-webkit-animation-delay: 0.4s; -moz-animation-delay: 0.4s; animation-delay: 0.4s;">
					<div class="widget">
						<h3 class="block-title">Useful Links</h3>
						<ul class="menu">
							<li><a href="<?php echo base_url('index.php') ?>"">Home</a></li>
							<!-- <li><a href=" #">Categories</a></li> -->
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-xs-12 wow fadeIn animated" data-wow-delay="0.6s" style="visibility: visible;-webkit-animation-delay: 0.6s; -moz-animation-delay: 0.6s; animation-delay: 0.6s;">
					<div class="widget">
						<h3 class="block-title">Latest </h3>
						<div class="twitter-content clearfix">
							<ul class="twitter-list">
								<li class="clearfix">
									<span>
										Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nesciunt modi, iusto cumque saepe doloribus laborum placeat odit reprehenderit esse recusandae ratione, neque vitae cum unde, temporibus magnam voluptatibus ipsam facilis.
										<a href="#">https://www.lipsum.com/</a>
									</span>
								</li>

							</ul>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>


	<div id="copyright">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="site-info float-left">
						<p>All Rights Reserved </p>
					</div>
					<div class="bottom-social-icons social-icon float-right">
						<a class="facebook" target="_blank" href="https://web.facebook.com/"><i class="fab fa-facebook-f"></i></a>
						<a class="twitter" target="_blank" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>

</footer>


<a href="#" class="back-to-top" style="display: block;">
	<i class="fas fa-angle-up"></i>
</a>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/jquery-min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/jquery.parallax.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/owl.carousel.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/jquery.slicknav.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/wow.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/jquery.counterup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/form-validator.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/contact-form-script.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/assets/js/main.js"></script>
<!-- End footer Area -->

</body>

</html>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
$this->load->view('header');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
</head>

<body>

	<div id="search-row-wrapper">
		<div class="container">
			<div class="search-inner">
				<div class="search-bar row">
					<fieldset>
						<form class="login-form" method="post" action="<?php echo base_url('index.php/welcome/filterSearch') ?>">

							<div class="form-group">
								<i class="lni-bullhorn"></i>
								<input type="text" name="customword" class="form-control" placeholder="What are you looking for">
							</div>
							<div class="form-group">
								<div class="tg-select">
									<select class="form-control" name="filter">
										<?php

										foreach ($a as $row) {
											echo '<option value="' . $row->job_category . '">' . $row->job_category . '</option>';
										}
										?>
									</select>


									<i class="fas fa-angle-down"></i>
								</div>
							</div>
							<!-- <button class="btn btn-primary log-btn" type="submit">Register</button> -->
							<button class="btn btn-common" type="submit"><i class="lni-search"></i> Search Now</button>&nbsp;
						</form>
					</fieldset>
				</div>
			</div>
		</div>
	</div>

	<div class="main-container">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-12 col-xs-12 page-sidebar">
					<aside>

						<div class="inner-box">
							<div class="widget-title">
								<h4>Ads </h4>
							</div>
							<img src="<?php echo base_url(); ?>/assets/assets/img/img1.jpg" alt="">
						</div>
						<div class="inner-box">
							<div class="widget-title">
								<h4>Ads </h4>
							</div>
							<img src="<?php echo base_url(); ?>/assets/assets/img/img1.jpg" alt="">
						</div>
						<div class="inner-box">
							<div class="widget-title">
								<h4>Ads </h4>
							</div>
							<img src="<?php echo base_url(); ?>/assets/assets/img/img1.jpg" alt="">
						</div>
					</aside>
				</div>
				<div class="col-lg-9 col-md-12 col-xs-12 page-content">
					<div class="adds-wrapper">
						<?php foreach ($a as $employee) {
							?>
							<div class="item-list">
								<div class="row">

									<div class="col-sm-3 no-padding photobox">


										<div class="add-image">
											<a href="<?php echo base_url('index.php/welcome/job_get') . '/' . $employee->id; ?>"><img src="<?php echo base_url(); ?>/assets/assets/img/item/img-1.jpg" alt=""></a>
										</div>
									</div>
									<div class="col-sm-9 add-desc-box">
										<div class="add-details">
											<h5 class="add-title"><a href="<?php echo base_url('index.php/welcome/job_get') . '/' . $employee->id; ?>"> <?= $employee->job_name; ?> </a></h5>
											<h9 class=" add-title"><?= $employee->job_location; ?></h9>

											<div class="job-location"></div>
											<div class="info">
												<span class="add-type"> <i class="fa fa-clock-o" aria-hidden="true"></i>
												</span>
												<span class="date">
													<?= $employee->upload_date; ?>
												</span> &nbsp; &nbsp;


												<span class="add-type"> <i class="fas fa-briefcase" aria-hidden="true"></i>
												</span>
												<span class="category"> &nbsp;<?= $employee->job_category; ?></span> &nbsp; &nbsp;

												<span class="add-type"> <i class="fa fa-money" aria-hidden="true"></i>
												</span>
												<span class="category"> &nbsp;<?= $employee->job_salary; ?>&nbsp;Kshs</span>

											</div>


											<div class="item_desc">
												<a href="<?php echo base_url('index.php/welcome/job_get') . '/' . $employee->id;  ?>"><?= $employee->job_description; ?></a>
											</div>
										</div>
									</div>

								</div>
							</div><?php
									} ?>

						<div class="col-12">

							<div class="pagination-bar">
								<nav>
									<ul class="pagination">
										<li class="page-item"><a class="page-link active " href="./">1</a></li>
										<li class="page-item"><a class="page-link  " href="#">2</a></li>

									</ul>
								</nav>
							</div>

							<div class="post-promo text-center">
								<h2> Ad Here </h2>


							</div>
						</div>

					</div>


				</div>
			</div>
		</div>
	</div>


</body>

</html>

<?php

$this->load->view('footer');

?>
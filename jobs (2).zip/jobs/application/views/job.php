<?php
defined('BASEPATH') or exit('No direct script access allowed');
$this->load->view('header');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
</head>

<body>

    <div id="search-row-wrapper">
        <div class="container">
            <div class="search-inner">
            </div>
        </div>
    </div>



    <div class="main-container">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-md-12 col-xs-12 page-content">

                    <div class="col-12">
                        <div class="post-promo text-center">
                            <h2> Ad Here </h2>

                        </div>
                    </div>

                    <br>
                    <h1 class="text-center" style="color:green;"><?php echo $this->session->flashdata('msg_update'); ?></h1>
                    <h1 class="text-center " style="color:red;"><?php echo $this->session->flashdata('msg_error'); ?></h1>
                    <div class="adds-wrapper">
                        <div class="item-list">
                            <?php foreach ($job_array as $view_job) {  ?>
                                <div class="row">

                                    <div class="col-sm-3 no-padding photobox">
                                        <div class="add-image">
                                            <a href="#"><img src="<?php echo base_url(); ?>/assets/assets/img/company-logos/howard.jpg" alt=""></a>
                                        </div>
                                    </div>
                                    <div class="col-sm-9 add-desc-box">

                                        <div class="add-details">
                                            <h5 class="add-title">Job Name: <?= $view_job->job_name;  ?> </h5>
                                            <br>
                                            <h9 class="add-title">Job Category: <?= $view_job->job_category;  ?>.</h9>

                                            <h9 class="add-title">
                                                <p class="pull-right"> <span class="add-type"><i class="fa fa-money" aria-hidden="true"></i> </span> Kshs: <?= $view_job->job_salary;  ?> </p>
                                            </h9> <BR>
                                            <hr><br><br><br>
                                            <h5 class="add-title"> <i class="fa fa-location-arrow " aria-hidden="true">&nbsp;</i><?= $view_job->job_location;  ?>
                                                <p class="pull-right"> <span class="add-type"><i class="fa fa-clock-o " aria-hidden="true"></i> </span> &nbsp;<?= $view_job->upload_date;  ?> </p>
                                            </h5>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        <div class="ad-detail-content">
                            <h5 class="add-title"> Job Description. </h5>
                            <blockquote>
                                <p> <?= $view_job->job_description;  ?>.</p>
                            </blockquote>
                        </div>

                        <div class="ad-detail-content">
                            <h5 class="add-title"> Job Information. </h5>
                            <blockquote>
                                <p> Job Duration : <?= $view_job->job_duration;  ?> Days.</p>
                            </blockquote>

                        </div>



                    </div>

                    <div class="item-list" align="center">
                        <div class="col-sm-12 add-desc-box ">

                            <hr>
                            <div class="add-details">
                                <?php
                                    if ($this->session->userData('fname')) {
                                        ?> <a class="btn btn-info btn-post" href="<?php echo base_url('index.php/welcome/apply') . '/' . $view_job->id; ?> ">
                                        <span class="fas fa-sign-in-alt"></span>&nbsp;Apply</a>
                                <?php  } else { ?>
                                    <a href="<?php echo base_url('index.php/welcome/login') ?>">
                                        <h4 style="color:blue;">Please Login to apply for this Job</h4>
                                    </a>
                                <?php } ?>


                            </div>
                            <hr>
                        </div>
                    </div>

                <?php
                } ?>
                </div>


            </div>
        </div>
    </div>
    </div>


    <?php

    $this->load->view('footer');

    ?>